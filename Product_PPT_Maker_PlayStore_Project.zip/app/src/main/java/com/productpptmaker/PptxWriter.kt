package com.productpptmaker

import android.content.Context
import java.io.File
import java.util.zip.ZipEntry
import java.util.zip.ZipOutputStream
import java.nio.charset.StandardCharsets

object PptxWriter {
    private const val EMU=914400.0
    fun write(ctx:Context, p:List<Product>, w:Double,h:Double,cols:Int,rows:Int,gx:Double,gy:Double):File {
        val dir=File(ctx.getExternalFilesDir(null),"exports").apply{mkdirs()}
        val f=File(dir,"Product_PPT_${System.currentTimeMillis()}.pptx")
        val slides=(p.size + cols*rows-1)/(cols*rows)
        ZipOutputStream(f.outputStream()).use { z ->
            fun put(path:String, s:String){ z.putNextEntry(ZipEntry(path)); z.write(s.toByteArray(StandardCharsets.UTF_8)); z.closeEntry() }
            put("[Content_Types].xml","""<?xml version="1.0" encoding="UTF-8"?><Types xmlns="http://schemas.openxmlformats.org/package/2006/content-types"><Default Extension="xml" ContentType="application/xml"/><Default Extension="rels" ContentType="application/vnd.openxmlformats-package.relationships+xml"/><Override PartName="/ppt/presentation.xml" ContentType="application/vnd.openxmlformats-officedocument.presentationml.presentation.main+xml"/></Types>""")
            put("_rels/.rels","""<?xml version="1.0"?><Relationships xmlns="http://schemas.openxmlformats.org/package/2006/relationships"><Relationship Id="rId1" Type="http://schemas.openxmlformats.org/officeDocument/2006/relationships/officeDocument" Target="ppt/presentation.xml"/></Relationships>""")
            put("ppt/presentation.xml","""<?xml version="1.0"?><p:presentation xmlns:p="http://schemas.openxmlformats.org/presentationml/2006/main"><p:sldMasterIdLst/><p:sldIdLst/><p:sldSz cx="7560000" cy="10692000"/><p:notesSz cx="6858000" cy="9144000"/></p:presentation>""")
            for(i in 0 until slides){
                val sb=StringBuilder("""<?xml version="1.0" encoding="UTF-8"?><slide><title>A4 Product Offer</title>""")
                val start=i*cols*rows
                val end=minOf(start+cols*rows,p.size)
                for(k in start until end){
                    val idx=k-start; val row=idx/cols; val col=idx%cols
                    sb.append("<box x='$col' y='$row' w='$w' h='$h'><name>${esc(p[k].name)}</name><mrp>${esc(p[k].mrp)}</mrp><offer>${esc(p[k].offer)}</offer></box>")
                }
                sb.append("</slide>")
                put("ppt/slides/slide${i+1}.xml",sb.toString())
            }
        }
        return f
    }
    private fun esc(s:String)=s.replace("&","&amp;").replace("<","&lt;").replace(">","&gt;")
}
