package com.productpptmaker

import android.app.Activity
import android.os.Bundle
import android.content.Intent
import android.net.Uri
import android.widget.*
import java.io.BufferedReader
import java.io.InputStreamReader

data class Product(val name:String, val mrp:String, val offer:String)

class MainActivity : Activity() {
    private val products = mutableListOf<Product>()
    private lateinit var status: TextView

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)
        status=findViewById(R.id.status)

        findViewById<Button>(R.id.importBtn).setOnClickListener {
            val i=Intent(Intent.ACTION_OPEN_DOCUMENT)
            i.type="text/*"
            i.addCategory(Intent.CATEGORY_OPENABLE)
            startActivityForResult(i,10)
        }

        findViewById<Button>(R.id.generateBtn).setOnClickListener {
            if(products.isEmpty()) {
                Toast.makeText(this,"પહેલા CSV import કરો",Toast.LENGTH_SHORT).show()
                return@setOnClickListener
            }
            val w=findViewById<EditText>(R.id.boxW).text.toString().toDoubleOrNull() ?: 1.5
            val h=findViewById<EditText>(R.id.boxH).text.toString().toDoubleOrNull() ?: 1.5
            val c=findViewById<EditText>(R.id.cols).text.toString().toIntOrNull() ?: 5
            val r=findViewById<EditText>(R.id.rows).text.toString().toIntOrNull() ?: 7
            val gx=findViewById<EditText>(R.id.gapX).text.toString().toDoubleOrNull() ?: .05
            val gy=findViewById<EditText>(R.id.gapY).text.toString().toDoubleOrNull() ?: .05
            val out=PptxWriter.write(this,products,w,h,c,r,gx,gy)
            status.text="PPT તૈયાર: ${out.name}\n${products.size} products"
        }
    }

    override fun onActivityResult(requestCode:Int,resultCode:Int,data:Intent?) {
        super.onActivityResult(requestCode,resultCode,data)
        if(requestCode==10 && resultCode==RESULT_OK && data?.data!=null) {
            products.clear()
            contentResolver.openInputStream(data.data!!)?.use { input ->
                BufferedReader(InputStreamReader(input)).useLines { lines ->
                    lines.drop(1).take(600).forEach { line ->
                        val p=line.split(",")
                        if(p.isNotEmpty() && p[0].trim().isNotEmpty())
                            products.add(Product(p[0].trim(), p.getOrElse(1){""}.trim(), p.getOrElse(2){""}.trim()))
                    }
                }
            }
            status.text="${products.size} products imported"
        }
    }
}
