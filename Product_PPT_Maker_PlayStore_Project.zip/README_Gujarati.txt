Product PPT Maker - Play Store Project

Features:
- Product photo રાખવાની જરૂર નથી
- Maximum 600 products
- CSV import
- A4 portrait layout
- Default 1.5 x 1.5 inch box
- Default 5 columns x 7 rows
- Box width/height, rows, columns અને gaps બદલી શકાય
- Multiple slides automatically

CSV format:
Product Name,MRP,Offer

નોંધ:
આ source project છે. Play Store પર મૂકવા માટે Android Studio માં signed AAB build કરીને Google Play Console મારફતે publish કરવું પડશે.
આ prototype નું PPT writer basic છે; final production release પહેલાં PPTX compatibility અને Excel import માટે testing જરૂરી છે.
